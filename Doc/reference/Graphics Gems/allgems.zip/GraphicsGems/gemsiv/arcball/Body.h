/**** Body.h ****/
#ifndef _H_Body
#define _H_Body
#include <gl/gl.h>
void drawbody(Matrix Rot);
#endif
