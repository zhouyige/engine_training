/* matrix.h
 *    The type and externs for matrix routines.
 */

typedef double ** Matrix;

extern double InvertMatrix();
extern Matrix NewMatrix();
